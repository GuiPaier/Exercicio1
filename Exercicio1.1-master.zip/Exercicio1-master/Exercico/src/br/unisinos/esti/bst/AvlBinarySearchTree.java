package br.unisinos.esti.bst;

public class AvlBinarySearchTree<K extends Comparable<K>, V> implements BinarySearchTreeADT<K, V> {
   protected Node root;

   protected class Node {
	    private K key;
	    private V value;
	    private int height;
	    private Node left, right;

	    public Node(K key, V value) {
	        this.key = key;
	        this.value = value;
	    }

	    public Node next(K other) {
	        return other.compareTo(key) < 0 ? left : right;
	    }

	    public boolean isLeaf() {
	        return left == null && right == null;
	    }

	    @Override
	    public String toString() {
	        return "" + key;
	    }
	    
	    private int height(Node node) {
	        return node != null ? node.height : -1;
	    }

	    private int balanceFactor(Node node) {
	        return height(node.left) - height(node.right);
	    }

	    
	    private Node doRightRotation(Node k2) {
	        Node k1 = k2.left;
	        k2.left = k1.right;
	        k1.right = k2;
	        k2.height = 1 + Math.max(height(k2.left), height(k2.right));
	        k1.height = 1 + Math.max(height(k1.left), height(k1.right));
	        return k1;
	    }
	 	
	 	private Node doLeftRotation(Node k1) {
	 	    Node k2 = k1.right;
	 	    k1.right = k2.left;
	 	    k2.left = k1;
	 	    k1.height = 1 + Math.max(height(k1.left), height(k1.right));
	 	    k2.height = 1 + Math.max(height(k2.left), height(k2.right));
	 	    return k2;
	 	}
	 	private Node insert(Node node, K key, V value) {
	 	    if (node == null) {
	 	        return new Node(key, value);
	 	    } else if (key.compareTo(node.key) > 0) {
	 	        node.right = insert(node.right, key, value);
	 	    } else if (key.compareTo(node.key) < 0) {
	 	        node.left = insert(node.left, key, value);
	 	    }
	 	    node.height = 1 + Math.max(height(node.left), height(node.right));
	 	    return balance(node);
	 	}
	 	public void insert(K key, V value) {
	 	    root = insert(root, key, value);
	 	}
	 	
	 	private Node balance(Node node) {
	 	    if (balanceFactor(node) < -1) {
	 	        if (balanceFactor(node.right) > 0) {
	 	            node.right = doRightRotation(node.right);
	 	        }
	 	        node = doLeftRotation(node);
	 	    } else if (balanceFactor(node) > 1) {
	 	        if (balanceFactor(node.left) < 0) {
	 	            node.left = doLeftRotation(node.left);
	 	        }
	 	        node = doRightRotation(node);
	 	    }
	 	    return node;
	 	}
	 	
	 	private Node deleteByCopying(Node node) {
	 	    if (node.right == null) {
	 	        return node.left;
	 	    }
	 	    node.right = deleteByCopying(node.right);
	 	    node.height = 1 + Math.max(height(node.left), height(node.right));
	 	    return balance(node);
	 	}

	 	public boolean delete(K key) {
		    if (search(key) != null) {
		        root = deleteByCopying(root, key);
		        return true;
		    }
		    return false;
		}

	 	public Node deleteByCopying(Node node, K key) {
	 	    if (key.compareTo(node.key) < 0) {
	 	        node.left = deleteByCopying(node.left, key);
	 	     } else if (key.compareTo(node.key) > 0) {
	 	        node.right = deleteByCopying(node.right, key);
	 	     } else {
	 	        if (node.left == null) {
	 	            return node.right;
	 	        } else if (node.right == null) {
	 	            return node.left;
	 	        } else {
	 	            Node temp = node;
	 	            node = node.left;
	 	            while (node.right != null)
	 	                node = node.right;

	 	            node.left = deleteByCopying(temp.left);
	 	            node.right = temp.right;
	 	        }
	 	     }
	 	     node.height = 1 + Math.max(height(node.left), height(node.right));
	 	     return balance(node);
	 	}

	    
	}
   

	
   @Override
   public void clear() {
      root = null;
   }

   @Override
   public boolean isEmpty() {
      return root == null;
   }

@Override
public V search(K key) {
	   return search(root, key);
	}

	private V search(Node node, K key) {
	   if (node == null) {
	       return null;
	   } else if (key.compareTo(node.key) == 0) {
	       return node.value;
	   }
	   return search(node.next(key), key);
	}
	
	


@Override
public void insert(K key, V value) {
	// TODO Auto-generated method stub
	
}

@Override
public boolean delete(K key) {
	// TODO Auto-generated method stub
	return false;
}

@Override
public void preOrder() {
	// TODO Auto-generated method stub
	
}

@Override
public void inOrder() {
	// TODO Auto-generated method stub
	
}


@Override
public void postOrder() {
	// TODO Auto-generated method stub
	
}

@Override
public void levelOrder() {
	// TODO Auto-generated method stub
	
}
}

