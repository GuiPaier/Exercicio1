package br.unisinos.esti.bst;

public class BinarySearchTreeTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
