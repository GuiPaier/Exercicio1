# Exercicio1
Trabalho Estruturas Avançadas de Dados I
